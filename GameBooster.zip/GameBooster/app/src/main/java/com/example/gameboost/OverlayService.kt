package com.example.gameboost

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var view: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            view?.text = buildInfo()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()                       // DND dikembalikan di onDestroy()
            return START_NOT_STICKY
        }
        startAsForeground()
        // Izin overlay bisa dicabut saat service di-restart sistem -> jangan crash
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (view == null) addOverlay()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("booster", "BOSTERn", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, "booster")
            .setSmallIcon(R.drawable.ic_stat_boost)
            .setColor(0xFFFF1744.toInt())
            .setContentTitle("BOSTERn aktif")
            .setContentText("Overlay monitor berjalan • BY nandar")
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
        val type = when {
            Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
            else -> 0
        }
        ServiceCompat.startForeground(this, 1, notif, type)
    }

    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            textSize = 11f
            val ph = (10 * d).toInt(); val pv = (6 * d).toInt()
            setPadding(ph, pv, ph, pv)
            background = GradientDrawable().apply {
                setColor(0xCC050507.toInt())
                setStroke((1 * d).toInt().coerceAtLeast(1), 0xAAFF1744.toInt())
                cornerRadius = 6 * d
            }
            text = buildInfo()
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }

        // Geser overlay dengan jari
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    runCatching { manager.updateViewLayout(tv, lp) }
                }
            }
            true
        }
        val added = runCatching { manager.addView(tv, lp) }.isSuccess
        if (!added) { stopSelf(); return }
        view = tv
        handler.post(ticker)
    }

    private fun buildInfo(): CharSequence {
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val usedMb = (mi.totalMem - mi.availMem) / 1048576
        val totalMb = mi.totalMem / 1048576
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pct = if (level >= 0) level * 100 / scale else 0

        val head = "BOSTERn"
        val sb = SpannableStringBuilder(head)
        sb.setSpan(ForegroundColorSpan(0xFFFF1744.toInt()), 0, head.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD_ITALIC), 0, head.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append("\nRAM $usedMb/$totalMb MB")
        sb.append("\nBAT $pct%  ").append(String.format(Locale.US, "%.1f", temp)).append("°C")
        return sb
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        view?.let { v -> runCatching { wm?.removeView(v) } }
        view = null
        Booster.restoreDnd(this)             // kembalikan mode DND lama kapan pun service berhenti
        super.onDestroy()
    }

    companion object { const val ACTION_STOP = "com.example.gameboost.STOP" }
}
