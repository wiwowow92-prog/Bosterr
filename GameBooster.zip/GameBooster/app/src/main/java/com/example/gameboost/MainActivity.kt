package com.example.gameboost

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class GameItem(val name: String, val pkg: String, val icon: Drawable)

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnDnd).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            Toast.makeText(this, "Booster dihentikan", Toast.LENGTH_SHORT).show()
        }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        findViewById<RecyclerView>(R.id.rvGames).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = GameAdapter(loadGames()) { boostAndLaunch(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        val o = if (Settings.canDrawOverlays(this)) "✔" else "✘"
        val d = if (Booster.hasDndAccess(this)) "✔" else "✘"
        tvStatus.text = "Overlay: $o   DND: $d"
    }

    private fun loadGames(): List<GameItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
        @Suppress("DEPRECATION")
        val games = all.filter {
            it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        }
        // Kalau tidak ada yang terdeteksi sebagai game, tampilkan semua app
        return (if (games.isNotEmpty()) games else all)
            .map { GameItem(pm.getApplicationLabel(it).toString(), it.packageName, pm.getApplicationIcon(it)) }
            .sortedBy { it.name.lowercase() }
    }

    private fun boostAndLaunch(game: GameItem) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin Overlay dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val killed = Booster.cleanRam(this)
        Booster.enableDnd(this)
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "$killed app dibersihkan", Toast.LENGTH_SHORT).show()
        packageManager.getLaunchIntentForPackage(game.pkg)?.let { startActivity(it) }
    }
}

class GameAdapter(
    private val items: List<GameItem>,
    private val onClick: (GameItem) -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val name: TextView = v.findViewById(R.id.tvName)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_game, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val g = items[i]
        h.icon.setImageDrawable(g.icon)
        h.name.text = g.name
        h.itemView.setOnClickListener { onClick(g) }
    }

    override fun getItemCount() = items.size
}
