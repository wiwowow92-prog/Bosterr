package com.example.gameboost

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

data class GameItem(val name: String, val pkg: String, val icon: Drawable)

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val games = mutableListOf<GameItem>()
    private lateinit var adapter: GameAdapter
    private lateinit var tvRam: TextView
    private lateinit var tvBat: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvResult: TextView
    private lateinit var btnOverlay: TextView
    private lateinit var btnDnd: TextView
    private lateinit var barRam: GlowBar
    private lateinit var barBat: GlowBar
    private lateinit var barTemp: GlowBar
    private lateinit var btnBoost: BoostButton
    private var boosting = false
    private val prefs by lazy { getSharedPreferences("lib", MODE_PRIVATE) }

    private val cRed = 0xFFFF1744.toInt()
    private val cOk = 0xFF3DFFA6.toInt()
    private val cOrange = 0xFFFF9100.toInt()
    private val cDim = 0xFF8A8A95.toInt()

    private val ticker = object : Runnable {
        override fun run() { updateStats(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvRam = findViewById(R.id.tvRam)
        tvBat = findViewById(R.id.tvBat)
        tvTemp = findViewById(R.id.tvTemp)
        tvResult = findViewById(R.id.tvResult)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnDnd = findViewById(R.id.btnDnd)
        barRam = findViewById(R.id.barRam)
        barBat = findViewById(R.id.barBat)
        barTemp = findViewById(R.id.barTemp)
        btnBoost = findViewById(R.id.btnBoost)

        btnOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnDnd.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<TextView>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            Toast.makeText(this, "BOSTERn dihentikan", Toast.LENGTH_SHORT).show()
        }
        btnBoost.setOnClickListener { boostOnly() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        adapter = GameAdapter(games, { boostAndLaunch(it) }, { confirmRemove(it) }, { showAdd() })
        findViewById<RecyclerView>(R.id.rvGames).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = this@MainActivity.adapter
        }
        refreshGames()

        // Intro hanya saat app benar-benar dibuka (bukan saat rotasi / recreate)
        val intro = findViewById<IntroView>(R.id.intro)
        if (savedInstanceState == null) {
            intro.play {
                enterAnimation()
                adapter.animate = true
                adapter.replay()
                adapter.notifyDataSetChanged()
            }
        } else {
            intro.visibility = View.GONE
            adapter.animate = true
        }
    }

    override fun onResume() {
        super.onResume()
        val o = Settings.canDrawOverlays(this); val d = Booster.hasDndAccess(this)
        btnOverlay.text = if (o) "Overlay ✔" else "Overlay ✘"; btnOverlay.setTextColor(if (o) cOk else cRed)
        btnDnd.text = if (d) "DND ✔" else "DND ✘"; btnDnd.setTextColor(if (d) cOk else cRed)
        handler.post(ticker)
    }

    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    // ---------- animasi masuk ----------
    private fun enterAnimation() {
        val ids = intArrayOf(R.id.header, R.id.cardRam, R.id.cardBat, R.id.cardTemp, R.id.btnBoost, R.id.tvResult, R.id.rowLib)
        val dy = 28f * resources.displayMetrics.density
        ids.forEachIndexed { i, id ->
            val v = findViewById<View>(id)
            v.alpha = 0f; v.translationY = dy
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(420)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- statistik ----------
    private fun avail(): Long {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi.availMem
    }

    private fun updateStats() {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val used = if (mi.totalMem > 0) ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt() else 0
        tvRam.text = "$used%"
        barRam.setValue(used / 100f, cRed)

        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pct = if (level >= 0) level * 100 / scale else -1
        tvBat.text = if (pct >= 0) "$pct%" else "--"
        barBat.setValue(if (pct >= 0) pct / 100f else 0f, if (pct in 0..19) cRed else cOk)
        tvTemp.text = String.format(Locale.US, "%.1f°", temp)
        barTemp.setValue(((temp - 20f) / 30f).coerceIn(0f, 1f), if (temp >= 40f) cRed else cOrange)
    }

    // ---------- boost ----------
    private fun boostOnly() {
        if (boosting) return
        boosting = true
        btnBoost.start()
        tvResult.setTextColor(cDim); tvResult.text = "Membersihkan..."
        val before = avail()
        // getInstalledApplications + kill bisa lambat -> jangan di main thread
        Thread {
            val n = Booster.cleanRam(this)
            handler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                val freed = ((avail() - before) / 1048576).coerceAtLeast(0)
                tvResult.setTextColor(cOk)
                tvResult.text = "$n app dibersihkan • RAM bebas +$freed MB"
                btnBoost.finish("+$freed MB")
                boosting = false
                updateStats()
            }, 900)
        }.start()
    }

    private fun boostAndLaunch(game: GameItem) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin Overlay dulu (tombol kanan atas)", Toast.LENGTH_SHORT).show()
            return
        }
        if (boosting) return
        boosting = true
        btnBoost.start()
        Thread {
            val n = Booster.cleanRam(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                Booster.enableDnd(this)
                startForegroundService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "$n app dibersihkan", Toast.LENGTH_SHORT).show()
                btnBoost.finish("$n APP")
                boosting = false
                packageManager.getLaunchIntentForPackage(game.pkg)?.let { startActivity(it) }
            }
        }.start()
    }

    // ---------- library game ----------
    private fun launchables(): List<ApplicationInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
    }

    @Suppress("DEPRECATION")
    private fun isGame(a: ApplicationInfo) =
        a.category == ApplicationInfo.CATEGORY_GAME || (a.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    private fun set(key: String) = prefs.getStringSet(key, emptySet())!!.toMutableSet()

    private fun refreshGames() {
        val pinned = set("pinned"); val hidden = set("hidden")
        games.clear()
        games.addAll(
            launchables()
                .filter { (isGame(it) || it.packageName in pinned) && it.packageName !in hidden }
                .map { GameItem(packageManager.getApplicationLabel(it).toString(), it.packageName, packageManager.getApplicationIcon(it)) }
                .sortedBy { it.name.lowercase() }
        )
        if (::adapter.isInitialized) { adapter.replay(); adapter.notifyDataSetChanged() }
    }

    private fun showAdd() {
        val have = games.map { it.pkg }.toSet()
        val cand = launchables().filter { it.packageName !in have }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
        val names = cand.map { packageManager.getApplicationLabel(it).toString() }.toTypedArray()
        val checked = BooleanArray(cand.size)
        AlertDialog.Builder(this)
            .setTitle("Tambah ke Game Library")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Tambah") { _, _ ->
                val pinned = set("pinned"); val hidden = set("hidden")
                cand.forEachIndexed { i, a -> if (checked[i]) { pinned.add(a.packageName); hidden.remove(a.packageName) } }
                prefs.edit().putStringSet("pinned", pinned).putStringSet("hidden", hidden).apply()
                refreshGames()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmRemove(g: GameItem) {
        AlertDialog.Builder(this)
            .setTitle("Hapus ${g.name} dari library?")
            .setMessage("App tidak di-uninstall, hanya disembunyikan dari daftar ini.")
            .setPositiveButton("Hapus") { _, _ ->
                val hidden = set("hidden"); hidden.add(g.pkg)
                val pinned = set("pinned"); pinned.remove(g.pkg)
                prefs.edit().putStringSet("hidden", hidden).putStringSet("pinned", pinned).apply()
                refreshGames()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

class GameAdapter(
    private val items: List<GameItem>,
    private val onClick: (GameItem) -> Unit,
    private val onLong: (GameItem) -> Unit,
    private val onAdd: () -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    /** Aktifkan animasi "pop" per item; di-set true setelah intro selesai. */
    var animate = false
    private var lastAnimated = -1
    fun replay() { lastAnimated = -1 }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val name: TextView = v.findViewById(R.id.tvName)
    }

    override fun getItemCount() = items.size + 1

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_game, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val density = h.icon.resources.displayMetrics.density
        val pad = (14 * density).toInt()
        val v = h.itemView
        if (i == items.size) {
            h.icon.setPadding(pad, pad, pad, pad)
            h.icon.setImageResource(R.drawable.ic_add)
            h.name.text = "Tambah"
            v.setOnClickListener { onAdd() }
            v.setOnLongClickListener(null)
        } else {
            val g = items[i]
            val p3 = (3 * density).toInt()
            h.icon.setPadding(p3, p3, p3, p3)
            h.icon.setImageDrawable(g.icon)
            h.name.text = g.name
            v.setOnClickListener { onClick(g) }
            v.setOnLongClickListener { onLong(g); true }
        }

        // efek tekan
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }

        // animasi masuk berurutan
        v.animate().cancel()
        if (animate && i > lastAnimated) {
            lastAnimated = i
            v.alpha = 0f; v.translationY = 24f * density; v.scaleX = 0.85f; v.scaleY = 0.85f
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay((i % 12) * 40L).setDuration(360).start()
        } else {
            v.alpha = 1f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f
        }
    }
}
