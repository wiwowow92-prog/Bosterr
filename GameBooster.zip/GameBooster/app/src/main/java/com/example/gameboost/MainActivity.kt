package com.example.gameboost

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class GameItem(val name: String, val pkg: String, val icon: Drawable)

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val games = mutableListOf<GameItem>()
    private lateinit var adapter: GameAdapter
    private lateinit var tvRam: TextView
    private lateinit var tvBat: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvResult: TextView
    private lateinit var btnOverlay: TextView
    private lateinit var btnDnd: TextView
    private val prefs by lazy { getSharedPreferences("lib", MODE_PRIVATE) }

    private val ticker = object : Runnable {
        override fun run() { updateStats(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvRam = findViewById(R.id.tvRam)
        tvBat = findViewById(R.id.tvBat)
        tvTemp = findViewById(R.id.tvTemp)
        tvResult = findViewById(R.id.tvResult)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnDnd = findViewById(R.id.btnDnd)

        btnOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnDnd.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<TextView>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            Toast.makeText(this, "BOSTERn dihentikan", Toast.LENGTH_SHORT).show()
        }
        findViewById<TextView>(R.id.btnBoost).setOnClickListener { v -> boostOnly(v) }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        adapter = GameAdapter(games, { boostAndLaunch(it) }, { confirmRemove(it) }, { showAdd() })
        findViewById<RecyclerView>(R.id.rvGames).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = this@MainActivity.adapter
        }
        refreshGames()
    }

    override fun onResume() {
        super.onResume()
        val ok = Color.parseColor("#3DFFA6"); val bad = Color.parseColor("#FF1744")
        val o = Settings.canDrawOverlays(this); val d = Booster.hasDndAccess(this)
        btnOverlay.text = if (o) "Overlay ✔" else "Overlay ✘"; btnOverlay.setTextColor(if (o) ok else bad)
        btnDnd.text = if (d) "DND ✔" else "DND ✘"; btnDnd.setTextColor(if (d) ok else bad)
        handler.post(ticker)
    }

    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    // ---------- statistik ----------
    private fun avail(): Long {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi.availMem
    }

    private fun updateStats() {
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        tvRam.text = "${(mi.totalMem - mi.availMem) * 100 / mi.totalMem}%"
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        tvBat.text = if (level >= 0) "${level * 100 / scale}%" else "--"
        tvTemp.text = "%.1f°".format(temp)
    }

    // ---------- boost ----------
    private fun boostOnly(v: View) {
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90)
            .withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
        val before = avail()
        val n = Booster.cleanRam(this)
        tvResult.text = "Membersihkan..."
        handler.postDelayed({
            val freed = ((avail() - before) / 1048576).coerceAtLeast(0)
            tvResult.text = "$n app ditutup • RAM bebas +$freed MB"
        }, 900)
    }

    private fun boostAndLaunch(game: GameItem) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin Overlay dulu (tombol kanan atas)", Toast.LENGTH_SHORT).show()
            return
        }
        val n = Booster.cleanRam(this)
        Booster.enableDnd(this)
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "$n app dibersihkan", Toast.LENGTH_SHORT).show()
        packageManager.getLaunchIntentForPackage(game.pkg)?.let { startActivity(it) }
    }

    // ---------- library game ----------
    private fun launchables(): List<ApplicationInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
    }

    @Suppress("DEPRECATION")
    private fun isGame(a: ApplicationInfo) =
        a.category == ApplicationInfo.CATEGORY_GAME || (a.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    private fun set(key: String) = prefs.getStringSet(key, emptySet())!!.toMutableSet()

    private fun refreshGames() {
        val pinned = set("pinned"); val hidden = set("hidden")
        games.clear()
        games.addAll(
            launchables()
                .filter { (isGame(it) || it.packageName in pinned) && it.packageName !in hidden }
                .map { GameItem(packageManager.getApplicationLabel(it).toString(), it.packageName, packageManager.getApplicationIcon(it)) }
                .sortedBy { it.name.lowercase() }
        )
        adapter.notifyDataSetChanged()
    }

    private fun showAdd() {
        val have = games.map { it.pkg }.toSet()
        val cand = launchables().filter { it.packageName !in have }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
        val names = cand.map { packageManager.getApplicationLabel(it).toString() }.toTypedArray()
        val checked = BooleanArray(cand.size)
        AlertDialog.Builder(this)
            .setTitle("Tambah ke Game Library")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Tambah") { _, _ ->
                val pinned = set("pinned"); val hidden = set("hidden")
                cand.forEachIndexed { i, a -> if (checked[i]) { pinned.add(a.packageName); hidden.remove(a.packageName) } }
                prefs.edit().putStringSet("pinned", pinned).putStringSet("hidden", hidden).apply()
                refreshGames()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmRemove(g: GameItem) {
        AlertDialog.Builder(this)
            .setTitle("Hapus ${g.name} dari library?")
            .setMessage("App tidak di-uninstall, hanya disembunyikan dari daftar ini.")
            .setPositiveButton("Hapus") { _, _ ->
                val hidden = set("hidden"); hidden.add(g.pkg)
                val pinned = set("pinned"); pinned.remove(g.pkg)
                prefs.edit().putStringSet("hidden", hidden).putStringSet("pinned", pinned).apply()
                refreshGames()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

class GameAdapter(
    private val items: List<GameItem>,
    private val onClick: (GameItem) -> Unit,
    private val onLong: (GameItem) -> Unit,
    private val onAdd: () -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val name: TextView = v.findViewById(R.id.tvName)
    }

    override fun getItemCount() = items.size + 1

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_game, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val pad = (14 * h.icon.resources.displayMetrics.density).toInt()
        if (i == items.size) {
            h.icon.setPadding(pad, pad, pad, pad)
            h.icon.setImageResource(R.drawable.ic_add)
            h.name.text = "Tambah"
            h.itemView.setOnClickListener { onAdd() }
            h.itemView.setOnLongClickListener(null)
        } else {
            val g = items[i]
            h.icon.setPadding(4, 4, 4, 4)
            h.icon.setImageDrawable(g.icon)
            h.name.text = g.name
            h.itemView.setOnClickListener { onClick(g) }
            h.itemView.setOnLongClickListener { onLong(g); true }
        }
    }
}
